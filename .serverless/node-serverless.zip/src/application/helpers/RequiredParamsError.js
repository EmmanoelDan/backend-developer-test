"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequiredParamsError = void 0;
class RequiredParamsError extends Error {
    constructor(message, statusCode = 500) {
        super(message);
        this._message = message;
        this._statusCode = statusCode;
    }
    get message() {
        return this._message;
    }
    get statusCode() {
        return this._statusCode;
    }
}
exports.RequiredParamsError = RequiredParamsError;
