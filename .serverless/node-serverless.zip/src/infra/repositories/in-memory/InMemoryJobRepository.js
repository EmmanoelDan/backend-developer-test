"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InMemoryJobRepository = void 0;
const JobStatus_1 = require("../../../domain/enum/JobStatus");
class InMemoryJobRepository {
    constructor() {
        this.jobs = [];
    }
    create(company_id, title, description, location, notes) {
        return __awaiter(this, void 0, void 0, function* () {
            this.jobs.push({ company_id: company_id, title: title, description: description, location: location, notes: notes });
            return this.jobs;
        });
    }
    findAll() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.jobs.push({
                id: 'd5167b78-5b4a-4aa3-8284-6172f8d0cc46',
                company_id: 'd5167b78-5b4a-4aa3-33s3',
                title: 'Developer Node Senior',
                description: 'Developer Node and typescript',
                location: 'Sao luis - MA',
                notes: "Clean code",
                status: JobStatus_1.Status.DRAFT,
                created_at: new Date,
                updated_at: new Date
            }, {
                id: 'd5167b78-5b4a-4aa3-8284-6172f8d0cc45',
                company_id: 'd5167b78-5b4a-4aa3-33s3',
                title: 'Developer Node Junior',
                description: 'Developer Node and typescript',
                location: 'Sao luis - MA',
                notes: "Clean code",
                status: JobStatus_1.Status.PUBLISHED,
                created_at: new Date,
                updated_at: new Date
            });
            return this.jobs;
        });
    }
    setStatusPublished(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const index = this.jobs.findIndex(x => x.id === id);
            if (index !== -1) {
                if (this.jobs[index].status === JobStatus_1.Status.DRAFT) {
                    this.jobs[index].status = JobStatus_1.Status.PUBLISHED;
                }
                else {
                    throw new Error("Jobs is Publish ready");
                }
            }
            return this.jobs[index];
        });
    }
    update(id, title, description, location, notes) {
        return __awaiter(this, void 0, void 0, function* () {
            const index = this.jobs.findIndex(x => x.id === id);
            if (index !== -1) {
                this.jobs[index].title = title;
                this.jobs[index].description = description;
                this.jobs[index].location = location;
                this.jobs[index].notes = notes;
                this.jobs[index];
            }
            this.jobs[index];
        });
    }
    find(id) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.jobs.push({
                id: 'd5167b78-5b4a-4aa3-8284-6172f8d0cc46',
                company_id: 'd5167b78-5b4a-4aa3-33s3',
                title: 'Developer Node Senior',
                description: 'Developer Node and typescript',
                location: 'Sao luis - MA',
                notes: "Clean code",
                status: JobStatus_1.Status.DRAFT,
                created_at: new Date,
                updated_at: new Date
            }, {
                id: 'd5167b78-5b4a-4aa3-8284-6172f8d0cc45',
                company_id: 'd5167b78-5b4a-4aa3-33s3',
                title: 'Developer Node Junior',
                description: 'Developer Node and typescript',
                location: 'Sao luis - MA',
                notes: "Clean code",
                status: JobStatus_1.Status.PUBLISHED,
                created_at: new Date,
                updated_at: new Date
            });
            const job = yield this.jobs.find(job => job.id === id);
            if (job) {
                return job;
            }
            return null;
        });
    }
    setStatusArchived(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const index = this.jobs.findIndex(jobStatus => jobStatus.id === id);
            if (index !== -1) {
                if (this.jobs[index].status === JobStatus_1.Status.PUBLISHED) {
                    this.jobs[index].status = JobStatus_1.Status.ARCHIVED;
                }
                this.jobs[index];
            }
            return this.jobs[index];
        });
    }
    delete(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const deleteJob = this.jobs.find(job => job.id === id);
            this.jobs = this.jobs.filter(job => job.status === JobStatus_1.Status.DRAFT);
            return this.jobs;
        });
    }
}
exports.InMemoryJobRepository = InMemoryJobRepository;
