"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InMemoryCompanyRepository = void 0;
const crypto_1 = require("crypto");
class InMemoryCompanyRepository {
    constructor() {
        this.companies = [];
    }
    create(company) {
        return __awaiter(this, void 0, void 0, function* () {
            this.companies.push(company);
        });
    }
    save(company) {
        return __awaiter(this, void 0, void 0, function* () {
            this.companies.push(company);
            return true;
        });
    }
    findAll() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.companies.push({ id: (0, crypto_1.randomUUID)(), name: 'ABC Corp', created_at: new Date, updated_at: new Date }, { id: (0, crypto_1.randomUUID)(), name: 'XYZ LLC', created_at: new Date, updated_at: new Date }, { id: (0, crypto_1.randomUUID)(), name: 'ACME Enterprises', created_at: new Date, updated_at: new Date });
            return this.companies;
        });
    }
    find(id) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.companies.push({ id: 'd5167b78-5b4a-4aa3-8284-6172f8d0cc46', name: 'ABC Corp', created_at: new Date, updated_at: new Date }, { id: (0, crypto_1.randomUUID)(), name: 'XYZ LLC', created_at: new Date, updated_at: new Date }, { id: (0, crypto_1.randomUUID)(), name: 'ACME Enterprises', created_at: new Date, updated_at: new Date });
            const company = yield this.companies.find(company => company.id === id);
            if (company) {
                return company;
            }
            return null;
        });
    }
}
exports.InMemoryCompanyRepository = InMemoryCompanyRepository;
