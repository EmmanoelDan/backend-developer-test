"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaJobRepository = void 0;
const client_1 = require("@prisma/client");
class PrismaJobRepository {
    constructor(_client) {
        this._client = _client;
    }
    findAll() {
        return __awaiter(this, void 0, void 0, function* () {
            const jobs = yield this._client.job.findMany();
            return jobs;
        });
    }
    create(company_id, title, description, location, notes) {
        return __awaiter(this, void 0, void 0, function* () {
            const job = yield this._client.job.create({
                data: {
                    company_id: company_id,
                    title: title,
                    description: description,
                    location: location,
                    notes: notes,
                }
            });
            return job;
        });
    }
    update(id, title, description, location, notes) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this._client.job.update({
                where: {
                    id: id
                },
                data: {
                    title: title,
                    description: description,
                    location: location,
                    notes: notes
                }
            });
            result;
        });
    }
    setStatusPublished(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this._client.job.update({
                where: {
                    id: id
                },
                data: {
                    status: client_1.job_status.published
                }
            });
            return result;
        });
    }
    find(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this._client.job.findUnique({
                where: {
                    id: id
                }
            });
            return result;
        });
    }
    setStatusArchived(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this._client.job.update({
                where: {
                    id: id
                },
                data: {
                    status: client_1.job_status.archived
                }
            });
            return result;
        });
    }
    delete(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this._client.job.findUnique({
                where: {
                    id: id
                },
            });
            if ((result === null || result === void 0 ? void 0 : result.status) === client_1.job_status.draft) {
                yield this._client.job.delete({
                    where: {
                        id
                    }
                });
            }
            return result;
        });
    }
}
exports.PrismaJobRepository = PrismaJobRepository;
