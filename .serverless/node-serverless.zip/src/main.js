"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = void 0;
const CreateJobUseCase_1 = require("./application/usecases/CreateJobUseCase");
const DeleteJobUseCase_1 = require("./application/usecases/DeleteJobUseCase");
const GetCompaniesUseCase_1 = require("./application/usecases/GetCompaniesUseCase");
const GetCompanyUseCase_1 = require("./application/usecases/GetCompanyUseCase");
const SetStatusArchiveUseCase_1 = require("./application/usecases/SetStatusArchiveUseCase");
const UpdateJobUseCase_1 = require("./application/usecases/UpdateJobUseCase");
const UpdateStatusJobUseCase_1 = require("./application/usecases/UpdateStatusJobUseCase");
const InMemoryCompanyRepository_1 = require("./infra/repositories/in-memory/InMemoryCompanyRepository");
const InMemoryJobRepository_1 = require("./infra/repositories/in-memory/InMemoryJobRepository");
const CreateJobController_1 = require("./presentation/controllers/CreateJobController");
const DeletedJobController_1 = require("./presentation/controllers/DeletedJobController");
const GetCompaniesController_1 = require("./presentation/controllers/GetCompaniesController");
const GetCompanyController_1 = require("./presentation/controllers/GetCompanyController");
const SetStatusArchivedController_1 = require("./presentation/controllers/SetStatusArchivedController");
const UpdateJobController_1 = require("./presentation/controllers/UpdateJobController");
const UpdateStatusController_1 = require("./presentation/controllers/UpdateStatusController");
const api_1 = require("./presentation/api");
const PrismaCompanyRepository_1 = require("./infra/repositories/prisma/PrismaCompanyRepository");
const PrismaJobRepository_1 = require("./infra/repositories/prisma/PrismaJobRepository");
const client_1 = require("@prisma/client");
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        // intance prima Client
        const prismaClient = new client_1.PrismaClient;
        // in-memory instances
        const inMemoryCompanyRepo = new InMemoryCompanyRepository_1.InMemoryCompanyRepository();
        const inMemoryJobRepo = new InMemoryJobRepository_1.InMemoryJobRepository();
        // prismaORM instance
        const prismaCompanyRepo = new PrismaCompanyRepository_1.PrismaCompanyRepository(prismaClient);
        const prismaJobRepo = new PrismaJobRepository_1.PrismaJobRepository(prismaClient);
        // Get all companies use cases
        const getCompaniesUseCase = new GetCompaniesUseCase_1.GetCompaniesUseCase(prismaCompanyRepo);
        const getCompaniesController = new GetCompaniesController_1.CompaniesController(getCompaniesUseCase);
        // Get By Company Use Case
        const getCompanyUseCase = new GetCompanyUseCase_1.GetCompanyUseCase(prismaCompanyRepo);
        const getCompanyController = new GetCompanyController_1.GetCompanyController(getCompanyUseCase);
        // Create Job Use Case
        const createJobUseCase = new CreateJobUseCase_1.CreateJobUseCase(prismaJobRepo);
        const createJobController = new CreateJobController_1.CreateJobController(createJobUseCase);
        // Update Status 
        const updatedStatusPublishUseCase = new UpdateStatusJobUseCase_1.UpdateStatusJobUseCase(prismaJobRepo);
        const updatedStatusPublishController = new UpdateStatusController_1.UpdateStatusController(updatedStatusPublishUseCase);
        // update job use case
        const updateJobUseCase = new UpdateJobUseCase_1.UpdateJobUseCase(prismaJobRepo);
        const updateJobController = new UpdateJobController_1.UpdateJobController(updateJobUseCase);
        // update archive use case
        const updateArchiveUseCase = new SetStatusArchiveUseCase_1.SetStatusArquivedUseCase(prismaJobRepo);
        const updateArchiveController = new SetStatusArchivedController_1.SetStatusArchivedController(updateArchiveUseCase);
        // delete job use case
        const deleteJobUseCase = new DeleteJobUseCase_1.DeleteJobUseCase(prismaJobRepo);
        const deleteJobController = new DeletedJobController_1.DeleteJobController(deleteJobUseCase);
        yield api_1.Api.run(5000, getCompaniesController, getCompanyController, createJobController, updatedStatusPublishController, updateJobController, updateArchiveController, deleteJobController);
    });
}
exports.main = main;
main();
