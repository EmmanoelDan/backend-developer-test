"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Status = void 0;
var Status;
(function (Status) {
    Status["DRAFT"] = "draft";
    Status["PUBLISHED"] = "published";
    Status["ARCHIVED"] = "archived";
    Status["REJECTED"] = "rejected";
})(Status || (exports.Status = Status = {}));
