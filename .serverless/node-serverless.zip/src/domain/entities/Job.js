"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Job = void 0;
class Job {
    constructor(id, company_id, title, description, location, notes, status, created_at, updated_at) {
        this.id = id;
        this.company_id = company_id;
        this.title = title;
        this.description = description;
        this.location = location;
        this.notes = notes;
        this.created_at = created_at;
        this.updated_at = updated_at;
        this.status = status;
    }
}
exports.Job = Job;
