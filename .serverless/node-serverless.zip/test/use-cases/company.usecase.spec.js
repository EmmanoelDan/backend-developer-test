"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const InMemoryCompanyRepository_1 = require("../../src/infra/repositories/in-memory/InMemoryCompanyRepository");
const crypto_1 = require("crypto");
(0, vitest_1.describe)('get companies', () => {
    (0, vitest_1.it)('should return a list of companies', () => __awaiter(void 0, void 0, void 0, function* () {
        const companyRepository = new InMemoryCompanyRepository_1.InMemoryCompanyRepository();
        const company = {
            id: (0, crypto_1.randomUUID)(),
            name: 'Google Inc.',
            created_at: new Date(),
            updated_at: new Date()
        };
        const response = yield companyRepository.findAll();
        (0, vitest_1.expect)(response).toBeInstanceOf(Array);
    }));
});
(0, vitest_1.describe)('get company by id', () => {
    (0, vitest_1.it)('Should be able to search for only one company per ID', () => __awaiter(void 0, void 0, void 0, function* () {
        const companyRepository = new InMemoryCompanyRepository_1.InMemoryCompanyRepository();
        const company = {
            id: (0, crypto_1.randomUUID)(),
            name: 'Google Inc.',
            created_at: new Date(),
            updated_at: new Date()
        };
        // const data = await companyRepository.items
        const response = yield companyRepository.find(company.id);
        // console.log(response)
        (0, vitest_1.expect)(response === null || response === void 0 ? void 0 : response.id);
    }));
    (0, vitest_1.it)('The ID must be valid', () => __awaiter(void 0, void 0, void 0, function* () {
        const companyRepository = new InMemoryCompanyRepository_1.InMemoryCompanyRepository();
        const company = {
            id: (0, crypto_1.randomUUID)(),
            name: 'Google Inc.',
            created_at: new Date(),
            updated_at: new Date()
        };
        const existCompanyId = company.id;
        const existCompoany = yield companyRepository.find(existCompanyId);
        (0, vitest_1.expect)(existCompoany).toBeDefined();
        // verify that the company exists: example company invalida
        const notExistCompanyId = '9999';
        const notExistCompany = yield companyRepository.find(notExistCompanyId);
        (0, vitest_1.expect)(notExistCompany).toBeNull();
    }));
});
(0, vitest_1.describe)('company name unique', () => {
    (0, vitest_1.it)('The company must have a unique name', () => __awaiter(void 0, void 0, void 0, function* () {
        const companyRepository = new InMemoryCompanyRepository_1.InMemoryCompanyRepository();
        const company = {
            id: (0, crypto_1.randomUUID)(),
            name: 'Google Inc.',
            created_at: new Date(),
            updated_at: new Date()
        };
        const data = yield companyRepository.companies;
        const newCompanyName = company.name;
        let errorOccured = false;
        // console.log(data)
        data.map((company) => __awaiter(void 0, void 0, void 0, function* () {
            if (newCompanyName === company.name) {
                errorOccured = false;
                (0, vitest_1.expect)(errorOccured).toBe(false);
            }
            else {
                errorOccured = true;
            }
        }));
        (0, vitest_1.expect)(errorOccured);
    }));
});
