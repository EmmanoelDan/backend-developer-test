"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const crypto_1 = require("crypto");
(0, vitest_1.test)('create a new company', () => {
    const company = {
        id: (0, crypto_1.randomUUID)(),
        name: 'Google Inc.',
        created_at: new Date(),
        updated_at: new Date()
    };
    (0, vitest_1.expect)(company);
    (0, vitest_1.expect)(company.name).toBe('Google Inc.');
});
