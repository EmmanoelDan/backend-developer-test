"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const JobStatus_1 = require("../../src/domain/enum/JobStatus");
(0, vitest_1.test)('create a new job', () => {
    const job = {
        id: 'd5167b78-5b4a-4aa3-8284-6172f8d0cc46',
        company_id: 'd5167b78-5b4a-4aa3-33s3',
        title: 'Developer Node Senior',
        description: 'Developer Node and typescript',
        location: 'Sao luis - MA',
        notes: 'Clean code',
        status: JobStatus_1.Status.DRAFT,
        created_at: new Date,
        updated_at: new Date
    };
    (0, vitest_1.expect)(job);
    (0, vitest_1.expect)(job.title).toBe('Developer Node Senior');
});
